﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
namespace libraryManagement
{
    public partial class adduser : System.Web.UI.Page
    {
        private string ConnectionString = "Server=localhost;Database=library_management;uid=root;pwd=secret";
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected override void OnPreInit(EventArgs e)
        {
            String thm = themeset.SelectedValue;

            if (Request["themeset"] != null)
            {

                String theme = Request["themeset"].ToString();

                Page.Theme = theme;
            }


            base.OnPreInit(e);
        }
        protected void btn_Click(object sender, EventArgs e)
        {
            string email=TextBox1.Text;
            string pwd=TextBox2.Text;
            MySqlConnection connection = new MySqlConnection(ConnectionString);
            string queryString = "select id,type, COUNT(*) From users where email=@email ANd password =@pwd group by type";
            MySqlCommand command = new MySqlCommand(queryString, connection);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@pwd", pwd);
            connection.Open();
            MySqlDataReader reader = command.ExecuteReader();
            try
            {
                reader.Read();
                if(int.Parse(reader[2].ToString())>0){

                    if (int.Parse(reader[1].ToString()) == 1)
                    {
                        Response.Redirect("dashboard.aspx");
                    }
                    else {
                        Session["userid"] = int.Parse(reader[0].ToString());
                        
                        Response.Redirect("userissue.aspx");
                    }                    
                }

            }
            catch(Exception ex){}
            finally
            {
                // Always call Close when done reading.
                reader.Close();
                connection.Close();
            }
        }

        protected void btn_Click1(object sender, EventArgs e)
        {

        }
    }
}

