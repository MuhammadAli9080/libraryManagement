﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
namespace libraryManagement
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        private string ConnectionString = "Server=localhost;Database=library_management;uid=root;pwd=secret";
        protected void Page_Load(object sender, EventArgs e)
        {
            string date = DateTime.Now.ToString();
            if (!Page.IsPostBack)
            {
               
                try
                {
                    string userid = Session["userid"].ToString();
                   
                }
                catch (Exception ex) {
                    Response.Redirect("login.aspx");
                }
                
                //TextBox2.Text = date;
                bindtable();

            }


        }


        private void bindtable()
        {
            using (MySqlConnection connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                try
                {
                    MySqlCommand command = connection.CreateCommand();
                    command.CommandType = CommandType.Text;
                    command.CommandText = "select * from books";
                    //MySqlDataAdapter adap = new MySqlDataAdapter("select id,name,email,password,roll_num,phone_number where type>1",connection);
                    command.ExecuteNonQuery();
                    DataSet ds = new DataSet();
                    MySqlDataAdapter db = new MySqlDataAdapter(command);
                    db.Fill(ds, "books");
                    viewUsers.DataSource = ds.Tables["books"];
                    viewUsers.DataBind();
                    DataTable dtble = new DataTable();
                    db = new MySqlDataAdapter(command);
                    db.Fill(dtble);
                    if (dtble.Rows.Count > 0)
                    {
                        bookdrpdn.DataSource = dtble;
                        bookdrpdn.DataTextField = "book_name";
                        bookdrpdn.DataValueField = "book_id";
                        bookdrpdn.DataBind();
                    }


                    //adap.Fill(ds,"users");
                    //viewUsers.DataSource = ds.Tables["users"];
                    //viewUsers.DataBind();

                    //viewUser.DataSource = ds.Tables[0].DefaultView;

                }
                catch (Exception ex) { }
                finally
                {
                    // Always call Close when done reading.
                    connection.Close();
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string bookname = TextBox1.Text;
            MySqlConnection connection = new MySqlConnection(ConnectionString);
            try
            {
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select * from books where book_name like '%" + bookname + "%'";
                //MySqlDataAdapter adap = new MySqlDataAdapter("select id,name,email,password,roll_num,phone_number where type>1",connection);
                command.ExecuteNonQuery();
                DataSet ds = new DataSet();
                MySqlDataAdapter db = new MySqlDataAdapter(command);
                db.Fill(ds, "books");                                           
                viewUsers.DataSource = ds.Tables["books"];
                viewUsers.DataBind();
            }
            catch (Exception ex) {
                Response.Write("Error:" + ex);
            }

        }


        protected void Button2_Click(object sender, EventArgs e)
        {
           
            string bookid = bookdrpdn.Text;
            int userid = int.Parse(Session["userid"].ToString());
            string Date = DateTime.Now.ToString();
            MySqlConnection connection = new MySqlConnection(ConnectionString);
            connection.Open();
            try
            {
                string queryString = "insert into userrequest (user_id,book_id,date) values(@useridField,@bookidField,@Date)";
                MySqlCommand command = new MySqlCommand(queryString, connection);
                    command.Parameters.AddWithValue("@useridField", userid);
                    command.Parameters.AddWithValue("@bookidField", bookid);
                    command.Parameters.AddWithValue("@Date", Date);
                command.ExecuteNonQuery();
                Session["RegisterMessage"] = "book \"" + bookdrpdn.SelectedItem.Text + "\" has been requested ";
                //Response.Redirect("userissue.aspx");
                
            }
            catch (Exception ex)
            {
                Response.Write("Error: "+ex);
            }
            finally
            {
                //  if (connection.state == ConnectionState.Open) {
                connection.Close();
                //loadData();
                // }
            }
        }

    }
}