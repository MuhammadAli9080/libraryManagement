﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
namespace libraryManagement
{
    public partial class Requestview : System.Web.UI.Page
    {
        private string ConnectionString = "Server=localhost;Database=library_management;uid=root;pwd=secret";
        protected void Page_Load(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection(ConnectionString);
            connection.Open();
            try
            {
                MySqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select * from userrequest";
                //MySqlDataAdapter adap = new MySqlDataAdapter("select id,name,email,password,roll_num,phone_number where type>1",connection);
                command.ExecuteNonQuery();
                DataSet ds = new DataSet();
                MySqlDataAdapter db = new MySqlDataAdapter(command);
                db.Fill(ds, "userrequest");
                viewUsers.DataSource = ds.Tables["userrequest"];
                viewUsers.DataBind();




                //adap.Fill(ds,"users");
                //viewUsers.DataSource = ds.Tables["users"];
                //viewUsers.DataBind();

                //viewUser.DataSource = ds.Tables[0].DefaultView;

            }
            catch (Exception ex) { }
            finally
            {
                // Always call Close when done reading.
                connection.Close();
            }
        }

        protected void viewUsers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }
}