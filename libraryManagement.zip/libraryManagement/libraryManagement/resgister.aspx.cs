﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
namespace libraryManagement
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        private string ConnectionString = "Server=localhost;Database=library_management;uid=root;pwd=secret";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void register(object sender, EventArgs e)
        {
            string nameField = name.Text;
            string emailField = email.Text;
            string passwordField = password.Text;
            string rollField = roll_num.Text;
            string phoneField = phone_num.Text;
            string typeField = utype.Text;




            MySqlConnection connection = new MySqlConnection(ConnectionString);
            MySqlCommand cmd;
            connection.Open();
            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = "insert into users(name,email,password,roll_num,phone_number,type) values(@name,@email,@password,@roll_num,@phone_num,@utype)";
                cmd.Parameters.AddWithValue("@name", nameField);
                cmd.Parameters.AddWithValue("@email", emailField);
                cmd.Parameters.AddWithValue("@password", passwordField);
                cmd.Parameters.AddWithValue("@roll_num", rollField);
                cmd.Parameters.AddWithValue("@phone_num", phoneField);
                cmd.Parameters.AddWithValue("@utype", typeField);
                cmd.ExecuteNonQuery();

                Session["RegisterMessage"] = "Hello "+nameField+ ", You have successfully registered";
                Response.Redirect("login.aspx");

            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                //  if (connection.state == ConnectionState.Open) {
                connection.Close();
                //loadData();
                // }
            }
        }
    }
}