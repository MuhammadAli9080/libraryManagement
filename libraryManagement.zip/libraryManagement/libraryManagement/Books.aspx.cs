﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
namespace libraryManagement
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        private string ConnectionString = "Server=localhost;Database=library_management;uid=root;pwd=secret";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            string booknameField = book_name.Text;
            string pirceField = price.Text;
            string category = cate.Text;

            MySqlConnection connection = new MySqlConnection(ConnectionString);
            MySqlCommand cmd;
            connection.Open();
            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = "insert into books(book_name,price,category) values(@book_name,@price,@cate)";
                cmd.Parameters.AddWithValue("@book_name", booknameField);
                cmd.Parameters.AddWithValue("@price", pirceField);
                cmd.Parameters.AddWithValue("@cate", DropDownList1.SelectedItem.Value);
                
                cmd.ExecuteNonQuery();

                Session["RegisterMessage"] = "CONGRATS" + booknameField + ",  NEW BOOK is Add";
                Response.Redirect("searchbook.aspx");

            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                //  if (connection.state == ConnectionState.Open) {
                connection.Close();
                //loadData();
                // }
            }
        }

        protected void btn2(object sender, EventArgs e)
        {
            string booknameField = book_name.Text;
            string pirceField = price.Text;
            string category = cate.Text;
            String ID = id.Text;

            MySqlConnection connection = new MySqlConnection(ConnectionString);
            MySqlCommand cmd;
            connection.Open();
            try
            {
               // Response.Write("abcd");
               // Response.End();
                cmd = connection.CreateCommand();
                cmd.CommandText = "update  books set book_name=@book_name,price=@price,category=@cate where book_id=@id";
                cmd.Parameters.AddWithValue("@book_name", booknameField);
                cmd.Parameters.AddWithValue("@price", pirceField);
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@cate", DropDownList1.SelectedItem.Value);

                cmd.ExecuteNonQuery();

                Session["RegisterMessage"] = "CONGRATS" + booknameField + ",  NEW BOOK is Add";
                Response.Redirect("searchbook.aspx");

            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                //  if (connection.state == ConnectionState.Open) {
                connection.Close();
                //loadData();
                // }
            }

        }

        protected void btn3(object sender, EventArgs e)
        {
            string booknameField = book_name.Text;
            string pirceField = price.Text;
            string category = cate.Text;
            String ID = id.Text;

            MySqlConnection connection = new MySqlConnection(ConnectionString);
            MySqlCommand cmd;
            connection.Open();
            try
            {
                // Response.Write("abcd");
                // Response.End();
                cmd = connection.CreateCommand();
                cmd.CommandText = "DELETE FROM books where book_id=@id";
                cmd.Parameters.AddWithValue("@book_name", booknameField);
                cmd.Parameters.AddWithValue("@price", pirceField);
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@cate", DropDownList1.SelectedItem.Value);

                cmd.ExecuteNonQuery();

                Session["RegisterMessage"] = "CONGRATS" + booknameField + ",  NEW BOOK is Add";
                Response.Redirect("searchbook.aspx");

            }
            catch (Exception ex)
            {
                Response.Write("Error:"+ex);
            }
            finally
            {
                //  if (connection.state == ConnectionState.Open) {
                connection.Close();
                //loadData();
                // }
            }

        }
    }
}