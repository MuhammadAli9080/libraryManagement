﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
namespace libraryManagement
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        private string ConnectionString = "Server=localhost;Database=library_management;uid=root;pwd=secret";
        protected void Page_Load(object sender, EventArgs e){
            string date = DateTime.Now.ToString(); 
            if(!Page.IsPostBack){
               dateInput.Text = date;
                bindtable();

            }
        }
        private void bindtable()
        {
            using (MySqlConnection connection = new MySqlConnection(ConnectionString))
            {
                MySqlDataAdapter adp = new MySqlDataAdapter("select id,name from users where type=2", connection);
                DataTable ds = new DataTable();
                adp.Fill(ds);
                if (ds.Rows.Count > 0)
                {
                    DropDownList1.DataSource = ds;
                    DropDownList1.DataTextField = "name";
                    DropDownList1.DataValueField = "id";
                    DropDownList1.DataBind();
                }
            }

            using (MySqlConnection connection = new MySqlConnection(ConnectionString))
            {
                MySqlDataAdapter adp = new MySqlDataAdapter("select book_id,book_name from books", connection);
                DataTable ds = new DataTable();
                adp.Fill(ds);
                if (ds.Rows.Count > 0)
                {
                    DropDownList2.DataSource = ds;
                    DropDownList2.DataTextField = "book_name";
                    DropDownList2.DataValueField = "book_id";
                    DropDownList2.DataBind();
                }


            } 
            try
            {
                //Response.Write(DateTime.Now.ToString());
                MySqlConnection connection = new MySqlConnection(ConnectionString);
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select name as Name,book_name as Book,date as Date from issuebook left join users on users.id=issuebook.user_id left join books on books.book_id=issuebook.book_id";
                //MySqlDataAdapter adap = new MySqlDataAdapter("select id,name,email,password,roll_num,phone_number where type>1",connection);
                command.ExecuteNonQuery();
                DataSet ds = new DataSet();
                MySqlDataAdapter db = new MySqlDataAdapter(command);
                db.Fill(ds, "books");
                viewUsers.DataSource = ds.Tables["books"];
                viewUsers.DataBind();
                connection.Close();

            }
            catch (Exception ex)
            {
                Response.Write("Error: "+ex.Message.ToString());
            }

        }


        






        protected void Button1_Click(object sender, EventArgs e)
        {
       
            Response.Write("Thank You For Issue Book" + DropDownList1.SelectedItem.Text);
            string bookname = DropDownList2.Text;
            string userField = DropDownList1.Text;
            string bookidField = DropDownList2.Text;
            string Date = DateTime.Now.ToString();
            MySqlConnection connection = new MySqlConnection(ConnectionString);
            MySqlCommand cmd;
            connection.Open();
            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = "insert into issuebook (USER_ID,BOOK_ID,date) values(@useridField,@bookidField,@Date)";
                cmd.Parameters.AddWithValue("@useridField", userField);
                cmd.Parameters.AddWithValue("@bookidField", bookidField);
                cmd.Parameters.AddWithValue("@Date", Date);
                cmd.Parameters.AddWithValue("@DropDownList1", DropDownList1.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@DropDownList2", DropDownList2.SelectedItem.Value);
                cmd.ExecuteNonQuery();
                Session["RegisterMessage"] = "book \"" + DropDownList2.SelectedItem.Text+"\" has been issued to "+DropDownList1.SelectedItem.Text;
                Response.Redirect("bookissue.aspx");
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                //  if (connection.state == ConnectionState.Open) {
                connection.Close();
                //loadData();
                // }
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void view(object sender, EventArgs e)
        {

        }

        
    }
}