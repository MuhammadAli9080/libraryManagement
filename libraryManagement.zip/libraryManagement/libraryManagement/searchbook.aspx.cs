﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

namespace libraryManagement
{
    public partial class searchbook : System.Web.UI.Page
    {
        private string ConnectionString = "Server=localhost;Database=library_management;uid=root;pwd=secret";
        protected void Page_Load(object sender, EventArgs e)
        {
            string date = DateTime.Now.ToString();
            if (!Page.IsPostBack)
            {

                
                bindtable();

            }


        }


        private void bindtable()
        {
            using (MySqlConnection connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                try
                {
                    MySqlCommand command = connection.CreateCommand();
                    command.CommandType = CommandType.Text;
                    command.CommandText = "select * from books";
                    //MySqlDataAdapter adap = new MySqlDataAdapter("select id,name,email,password,roll_num,phone_number where type>1",connection);
                    command.ExecuteNonQuery();
                    DataSet ds = new DataSet();
                    MySqlDataAdapter db = new MySqlDataAdapter(command);
                    db.Fill(ds, "books");
                    viewUsers.DataSource = ds.Tables["books"];
                    viewUsers.DataBind();
                    DataTable dtble = new DataTable();
                    db = new MySqlDataAdapter(command);
                    db.Fill(dtble);
                   


                    //adap.Fill(ds,"users");
                    //viewUsers.DataSource = ds.Tables["users"];
                    //viewUsers.DataBind();

                    //viewUser.DataSource = ds.Tables[0].DefaultView;

                }
                catch (Exception ex) { }
                finally
                {
                    // Always call Close when done reading.
                    connection.Close();
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string bookname = TextBox1.Text;
            MySqlConnection connection = new MySqlConnection(ConnectionString);
            try
            {
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select * from books where book_name like '%" + bookname + "%'";
                //MySqlDataAdapter adap = new MySqlDataAdapter("select id,name,email,password,roll_num,phone_number where type>1",connection);
                command.ExecuteNonQuery();
                DataSet ds = new DataSet();
                MySqlDataAdapter db = new MySqlDataAdapter(command);
                db.Fill(ds, "books");
                viewUsers.DataSource = ds.Tables["books"];
                viewUsers.DataBind();
            }
            catch (Exception ex)
            {
                Response.Write("Error:" + ex);
            }

        }


       
        }
    }
